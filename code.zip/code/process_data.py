# 添加属性n_idx
# 将edge_index 转换成 torch.long
# 数据集划分信息

import argparse
import os
from torch_geometric.data import HeteroData
import torch
import numpy as np
from tqdm import tqdm
import os.path as osp
import pickle as pkl

# 调整为更合理的批次大小，适应29G内存
EDGE_BATCH_SIZE = 10_000_000  # 每批处理1000万条边
NODE_BATCH_PROCESS = 1_000_000  # 节点处理进度更新间隔

# 预估大小（根据实际数据调整）
edge_size = 157_814_864
node_size = 13_806_619


def read_node_atts(node_files, pyg_file, label_file=None):
    # 检查是否已处理
    if osp.exists(pyg_file + ".nodes.pyg"):
        nodes = pkl.load(open(pyg_file + ".nodes.pyg", 'rb'))
        return nodes['maps'], nodes['embeds'], nodes['labels']['item']

    node_maps = {}  # {node_type: {original_id: new_id}}
    node_embeds = {}  # {node_type: list of embeddings}
    lack_num = {}
    total_count = 0

    # 初始化进度条
    process = tqdm(total=node_size, desc="Processing nodes")

    for node_file in node_files:
        # 按行读取，避免一次性加载整个文件
        with open(node_file, 'r') as rf:
            for line in rf:
                line = line.strip()
                if not line:
                    continue
                info = line.split(",")
                if len(info) < 2:
                    continue  # 跳过无效行

                try:
                    node_id = int(info[0])
                    node_type = info[1].strip()
                except (ValueError, IndexError):
                    continue  # 跳过格式错误行

                # 初始化类型字典
                if node_type not in node_maps:
                    node_maps[node_type] = {}
                    node_embeds[node_type] = []
                    lack_num[node_type] = 0

                # 处理节点ID映射（去重）
                if node_id not in node_maps[node_type]:
                    new_id = len(node_maps[node_type])
                    node_maps[node_type][node_id] = new_id

                    # 处理嵌入向量
                    if len(info) >= 3 and len(info[2]) >= 50:
                        embedding = np.array(info[2].split(":"), dtype=np.float32)
                    else:
                        embedding = np.zeros(256, dtype=np.float32)
                        lack_num[node_type] += 1

                    node_embeds[node_type].append(embedding)
                else:
                    new_id = node_maps[node_type][node_id]

                total_count += 1
                if total_count % NODE_BATCH_PROCESS == 0:
                    process.update(NODE_BATCH_PROCESS)

    process.close()

    # 打印节点统计信息
    print(f"Total nodes processed: {total_count}")
    print("Node types:", node_maps.keys())
    for node_type in node_maps:
        print(f"{node_type}: Total={len(node_maps[node_type])}, Lack={lack_num[node_type]}")

    # 处理标签
    labels = []
    if label_file and osp.exists(label_file):
        with open(label_file, 'r') as lf:
            for line in lf:
                line = line.strip()
                if not line:
                    continue
                parts = line.split(",")
                if len(parts) != 2:
                    continue
                try:
                    item_id = int(parts[0])
                    label = int(parts[1])
                    if 'item' in node_maps and item_id in node_maps['item']:
                        labels.append([node_maps['item'][item_id], label])
                except ValueError:
                    continue

    # 保存处理结果（使用更紧凑的格式）
    nodes_dict = {
        'maps': node_maps,
        'embeds': {k: np.array(v, dtype=np.float32) for k, v in node_embeds.items()},
        'labels': {'item': labels}
    }
    # 创建存储目录
    os.makedirs(osp.dirname(pyg_file), exist_ok=True)
    pkl.dump(nodes_dict, open(pyg_file + ".nodes.pyg", 'wb'), pkl.HIGHEST_PROTOCOL)
    print("Node data saved")

    return node_maps, node_embeds, labels


def format_pyg_graph(edge_file, node_files, pyg_file, label_file=None):
    # 检查是否已有处理好的图数据
    if osp.exists(pyg_file + ".pt") and not args.reload:
        return torch.load(pyg_file + ".pt")

    # 读取节点数据
    node_maps, node_embeds, labels = read_node_atts(node_files, pyg_file, label_file)

    # 初始化异质图
    graph = HeteroData()

    # 处理节点特征（使用numpy直接转换，减少内存占用）
    print("Converting node features")
    for node_type in tqdm(node_maps.keys(), desc="Node types"):
        # 直接从numpy数组转换为torch张量
        embeds_np = np.array(node_embeds[node_type], dtype=np.float32)
        graph[node_type].x = torch.from_numpy(embeds_np)
        graph[node_type].num_nodes = len(node_maps[node_type])
        graph[node_type].maps = node_maps[node_type]
        graph[node_type].n_id = torch.arange(len(node_maps[node_type]), dtype=torch.long)
        del embeds_np  # 释放内存

    # 处理标签和数据集划分
    if label_file and 'item' in graph:
        print("Processing labels")
        item_count = len(node_maps['item'])
        graph['item'].y = torch.full((item_count,), -1, dtype=torch.long)
        for idx, label in tqdm(labels, desc="Labels"):
            if idx < item_count:  # 防止索引越界
                graph['item'].y[idx] = label

        # 划分数据集
        indices = (graph['item'].y != -1).nonzero().squeeze()
        if indices.ndim == 0:
            indices = indices.unsqueeze(0)  # 处理单元素情况
        print(f"Labeled nodes: {indices.shape[0]}")

        # 随机划分
        train_val_random = torch.randperm(indices.shape[0])
        split = int(indices.shape[0] * 0.8)
        graph['item'].train_idx = indices[train_val_random[:split]]
        graph['item'].val_idx = indices[train_val_random[split:]]

    # 分批次处理边数据（核心优化）
    print("Processing edges in batches")
    edge_process = tqdm(total=edge_size, desc="Edges")
    edge_buffers = {}  # 临时缓存当前批次的边数据

    with open(edge_file, 'r') as rf:
        for line in rf:
            line = line.strip()
            if not line:
                continue
            parts = line.split(",")
            if len(parts) != 5:
                continue  # 跳过无效边

            try:
                src_id = int(parts[0])
                dst_id = int(parts[1])
                src_type = parts[2].strip()
                dst_type = parts[3].strip()
                edge_type = parts[4].strip()
            except (ValueError, IndexError):
                continue

            # 检查节点类型是否存在
            if src_type not in node_maps or dst_type not in node_maps:
                continue
            # 检查节点ID是否存在
            if src_id not in node_maps[src_type] or dst_id not in node_maps[dst_type]:
                continue

            # 转换为内部ID
            src_internal = node_maps[src_type][src_id]
            dst_internal = node_maps[dst_type][dst_id]

            # 缓存边数据
            key = (src_type, edge_type, dst_type)
            if key not in edge_buffers:
                edge_buffers[key] = {'source': [], 'dest': []}
            edge_buffers[key]['source'].append(src_internal)
            edge_buffers[key]['dest'].append(dst_internal)

            # 当缓存达到批次大小时，处理并清空缓存
            if sum(len(v['source']) for v in edge_buffers.values()) >= EDGE_BATCH_SIZE:
                for key, data in edge_buffers.items():
                    src_tensor = torch.tensor(data['source'], dtype=torch.long)
                    dst_tensor = torch.tensor(data['dest'], dtype=torch.long)
                    edge_index = torch.vstack([src_tensor, dst_tensor])
                    
                    # 如果边已经存在，拼接；否则创建
                    if key in graph.edge_index_dict:
                        graph[key].edge_index = torch.cat([graph[key].edge_index, edge_index], dim=1)
                    else:
                        graph[key].edge_index = edge_index
                    
                # 清空缓存并更新进度
                edge_buffers.clear()
                edge_process.update(EDGE_BATCH_SIZE)

    # 处理剩余的边数据
    for key, data in edge_buffers.items():
        if data['source']:  # 只处理非空数据
            src_tensor = torch.tensor(data['source'], dtype=torch.long)
            dst_tensor = torch.tensor(data['dest'], dtype=torch.long)
            graph[key].edge_index = torch.vstack([src_tensor, dst_tensor])
    edge_process.close()

    # 边类型排序（保持原有逻辑）
    edge_order = [
        ('b', 'A_1', 'item'), ('f', 'B', 'item'), ('a', 'G_1', 'f'),
        ('f', 'G', 'a'), ('a', 'H_1', 'e'), ('f', 'C', 'd'),
        ('f', 'D', 'c'), ('c', 'D_1', 'f'), ('f', 'F', 'e'),
        ('item', 'B_1', 'f'), ('item', 'A', 'b'), ('e', 'F_1', 'f'),
        ('e', 'H', 'a'), ('d', 'C_1', 'f')
    ]
    for edge_type in edge_order:
        if edge_type in graph.edge_types:
            graph[edge_type].edge_index = graph[edge_type].edge_index  # 触发重新排序

    # 保存最终图数据
    torch.save(graph, pyg_file + ".pt")
    print(f"Graph saved to {pyg_file}.pt")
    return graph


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--reload', action='store_true', help="Force reload node features")
    parser.add_argument('--session', type=int, default=1, help="Session 1 or 2")
    args = parser.parse_args()

    assert args.session in [1, 2], "Session must be 1 or 2"

    if args.session == 1:
        # Session I 配置（Kaggle路径）
        node_files = [
            '/kaggle/input/sessionedge/icdm2022_session1_nodes1/icdm2022_session1_nodes1.csv',
            '/kaggle/input/sessionedge/icdm2022_session1_nodes2/icdm2022_session1_nodes2.csv'
        ]
        graph_path = '/kaggle/input/sessionedge/icdm2022_session1_edges.csv/icdm2022_session1_edges.csv'
        label_path = '/kaggle/input/sessionedge/icdm2022_session1_train_labels.csv/icdm2022_session1_train_labels.csv'
        store_path = '/kaggle/working/session1/icdm2022_session1'
    else:
        # Session II 配置
        node_files = ['/kaggle/input/sessionedge/icdm2022_session2/icdm2022_session2_nodes.csv']
        graph_path = '/kaggle/input/sessionedge/icdm2022_session2/icdm2022_session2_edges.csv'
        label_path = None
        store_path = '/kaggle/working/session2/icdm2022_session2'

    # 创建工作目录
    os.makedirs(osp.dirname(store_path), exist_ok=True)
    
    # 执行处理
    format_pyg_graph(graph_path, node_files, store_path, label_path)